package io.sim;

import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

import de.tudresden.sumo.cmd.*;
import de.tudresden.sumo.objects.SumoPosition2D;
import it.polito.appeal.traci.SumoTraciConnection;

public class GlobalCollector {

    private final SumoTraciConnection sumo;
    private final Set<String> monitoredEdges = Set.of("E_SN", "E_WL");
    private final Map<String, Boolean> collectingMap = new HashMap<>();
    private final Map<String, Long> enterTime = new HashMap<>();
    private final Map<String, Double> waitTime = new HashMap<>();
    private final Map<String, Double> lastSeenTimestamp = new HashMap<>();
    private final Map<String, String> lastEdgeMap = new HashMap<>();
    private final Map<String, String> startEdgeMap = new HashMap<>();
    private final Map<String, List<double[]>> trafficHistory = new HashMap<>();
    private final int stopSpeedThreshold = 1;
    private final int historySize = 10;
    private FileWriter csvWriter;

    private int currentPhaseIndex = 0;

    public GlobalCollector(SumoTraciConnection sumo) {
        this.sumo = sumo;
        try {
            this.csvWriter = new FileWriter("data/traffic_data.csv");
            csvWriter.append("timestamp,vehicle_id,edge_id,x,y,speed,signal_E_SN,signal_E_WL,travel_time,wait_time,queue_length\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void collect() {
        try {
            List<String> vehicles = (List<String>) sumo.do_job_get(Vehicle.getIDList());
            long timeMs = ((Number) sumo.do_job_get(Simulation.getCurrentTime())).longValue();
            double timestamp = timeMs / 1000.0;

            Set<String> currentVehicles = new HashSet<>(vehicles);
            Set<String> toRemove = new HashSet<>();

            for (String id : collectingMap.keySet()) {
                if (!currentVehicles.contains(id)) {
                    toRemove.add(id);
                }
            }

            for (String id : toRemove) {
                collectingMap.remove(id);
                enterTime.remove(id);
                waitTime.remove(id);
                lastSeenTimestamp.remove(id);
                lastEdgeMap.remove(id);
                startEdgeMap.remove(id);
            }

            for (String vehId : vehicles) {
                try {
                    String edgeId = (String) sumo.do_job_get(Vehicle.getRoadID(vehId));
                    lastEdgeMap.putIfAbsent(vehId, edgeId);
                    String lastEdge = lastEdgeMap.get(vehId);

                    if (monitoredEdges.contains(edgeId) && !collectingMap.containsKey(vehId)) {
                        collectingMap.put(vehId, true);
                        enterTime.put(vehId, timeMs);
                        waitTime.put(vehId, 0.0);
                        lastSeenTimestamp.put(vehId, timestamp);
                        startEdgeMap.put(vehId, edgeId);
                    }

                    if (!monitoredEdges.contains(edgeId)
                            && monitoredEdges.contains(startEdgeMap.getOrDefault(vehId, ""))
                            && collectingMap.containsKey(vehId)) {

                        long enter = enterTime.getOrDefault(vehId, timeMs);
                        double travelTime = (timeMs - enter) / 1000.0;
                        double totalWait = waitTime.getOrDefault(vehId, 0.0);

                        csvWriter.append(String.format(Locale.US,
                                "%.2f,%s,%s,,,0.0,,,%f,%f,\n",
                                timestamp, vehId, edgeId, travelTime, totalWait));
                        csvWriter.flush();

                        collectingMap.remove(vehId);
                        enterTime.remove(vehId);
                        waitTime.remove(vehId);
                        lastSeenTimestamp.remove(vehId);
                        lastEdgeMap.remove(vehId);
                        startEdgeMap.remove(vehId);

                        continue;
                    }

                    if (Boolean.TRUE.equals(collectingMap.get(vehId))) {
                        double speed = (double) sumo.do_job_get(Vehicle.getSpeed(vehId));
                        SumoPosition2D pos = (SumoPosition2D) sumo.do_job_get(Vehicle.getPosition(vehId));

                        String tlsState = (String) sumo.do_job_get(Trafficlight.getRedYellowGreenState("0"));
                        String signal_E_SN = tlsState.length() > 0 ? String.valueOf(tlsState.charAt(0)) : "?";
                        String signal_E_WL = tlsState.length() > 2 ? String.valueOf(tlsState.charAt(2)) : "?";

                        double lastTs = lastSeenTimestamp.getOrDefault(vehId, timestamp);
                        double deltaTime = timestamp - lastTs;
                        lastSeenTimestamp.put(vehId, timestamp);

                        if (speed < stopSpeedThreshold) {
                            double w = waitTime.getOrDefault(vehId, 0.0);
                            waitTime.put(vehId, w + deltaTime);
                        }

                        int queueLength = getStoppedVehicles(edgeId, vehicles);

                        csvWriter.append(String.format(Locale.US,
                                "%.2f,%s,%s,%.2f,%.2f,%.2f,%s,%s,,,%d\n",
                                timestamp, vehId, edgeId, pos.x, pos.y, speed,
                                signal_E_SN, signal_E_WL, queueLength));
                        csvWriter.flush();

                        double[] dataPoint = new double[]{queueLength};
                        trafficHistory.computeIfAbsent(edgeId, k -> new ArrayList<>()).add(dataPoint);
                        List<double[]> history = trafficHistory.get(edgeId);
                        if (history.size() > historySize) {
                            history.remove(0);
                        }
                    }

                    lastEdgeMap.put(vehId, edgeId);

                } catch (Exception e) {
                    if (!e.getMessage().contains("is not known")) {
                        System.err.printf("⚠ Erro ao coletar dados do veículo %s: %s\n", vehId, e.getMessage());
                    }
                }
            }

            if (trafficHistory.containsKey("E_WL") && trafficHistory.get("E_WL").size() >= 10) {
                List<double[]> history = trafficHistory.get("E_WL");
                double[] sequence = new double[10];
                int start = Math.max(0, history.size() - 10);
                for (int i = 0; i < history.size() - start; i++) {
                    sequence[10 - (history.size() - start) + i] = history.get(start + i)[0];
                }

                double predictedQueue = TrafficPredictor.predictQueueLength(sequence);
                System.out.println("📊 Previsão fila E_WL: " + predictedQueue);

                int currentPhase = (int) sumo.do_job_get(Trafficlight.getPhase("0"));
                if (predictedQueue > 8.3 && (currentPhase != 2 && currentPhase != 3)) {
                    sumo.do_job_set(Trafficlight.setPhase("0", 2)); // E_WL verde
               }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private int getStoppedVehicles(String edgeId, List<String> vehicles) {
        int count = 0;
        for (String vehId : vehicles) {
            try {
                String vehEdge = (String) sumo.do_job_get(Vehicle.getRoadID(vehId));
                if (edgeId.equals(vehEdge)) {
                    double speed = (double) sumo.do_job_get(Vehicle.getSpeed(vehId));
                    if (speed < stopSpeedThreshold) count++;
                }
            } catch (Exception e) {
                if (!e.getMessage().contains("is not known")) {
                    System.err.printf("⚠ Erro ao contar veículo parado %s: %s\n", vehId, e.getMessage());
                }
            }
        }
        return count;
    }
}
