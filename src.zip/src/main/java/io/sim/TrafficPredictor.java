package io.sim;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class TrafficPredictor {

    public static double predictQueueLength(double[] sequence) {
        try {
            URL url = new URL("http://localhost:5000/predict");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            // Construir JSON com apenas fila
            StringBuilder json = new StringBuilder();
            json.append("{\"sequence\":[");

            for (int i = 0; i < sequence.length; i++) {
                json.append(sequence[i]);
                if (i < sequence.length - 1) json.append(",");
            }

            json.append("]}");

            OutputStream os = conn.getOutputStream();
            byte[] input = json.toString().getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);

            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                response.append(line.trim());
            }

            String responseBody = response.toString();
            int start = responseBody.indexOf(":") + 1;
            int end = responseBody.indexOf("}");
            String value = responseBody.substring(start, end);
            return Double.parseDouble(value);

        } catch (Exception e) {
            System.err.println("Erro ao chamar o microserviço de predição: " + e.getMessage());
            return -1;
        }
    }
}
