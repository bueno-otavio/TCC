package io.sim;

import java.io.IOException;
import java.util.List;

import it.polito.appeal.traci.SumoTraciConnection;

public class EnvSimulator extends Thread {

    private SumoTraciConnection sumo;
    private GlobalCollector collector;

    public EnvSimulator() {}

    @Override
    public void run() {
        String sumo_bin = "sumo-gui";
        String config_file = "map/cross.sumocfg";

        sumo = new SumoTraciConnection(sumo_bin, config_file);
        sumo.addOption("start", "1");
        sumo.addOption("quit-on-end", "0");
        sumo.addOption("step-length", "1"); // passo da simulação em segundos

        try {
            sumo.runServer(12345);

            collector = new GlobalCollector(sumo); // sem thread separada

            // 🚨 Loop principal da simulação
            while (!sumo.isClosed()) {
                sumo.do_timestep();       // avança simulação 1 passo
                collector.collect();      // coleta sincronizada com timestep
                Thread.sleep(100);        // (opcional) para evitar sobrecarga de CPU
            }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}